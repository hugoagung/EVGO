<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }

    public function index()
    {
        $data['title'] = 'Halaman Utama';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar', $data);
        $this->load->view('template/topbar', $data);
        $this->load->view('user/index', $data);
        $this->load->view('template/footer');
    }

    public function stok_barang()
    {
        $this->load->model('stok_model');
        $data['title'] = 'Stok Barang ';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['Stok_barang'] = $this->stok_model->ambil_semua_barang_masuk();

        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar', $data);
        $this->load->view('template/topbar', $data);
        $this->load->view('barang/stokbarang2');
        $this->load->view('template/footer');
    }

  

    public function barang_masuk()
    {
        $this->load->model('transaksi_model');
        $this->load->model('stok_model');
        $data['title'] = 'Barang masuk ';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        // MISALNYA lu masu ngambil db barang masuk di model tadi
        $data['Barang_masuk'] = $this->transaksi_model->barang_masuk(); // kok eror asu mana gw tau asw 
        $data['barang'] = $this->stok_model->ambil_semua_barang_masuk();

        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar', $data);
        $this->load->view('template/topbar', $data);
        $this->load->view('barang/barang_masuk');
        $this->load->view('template/footer');
    }

    public function tambah_barang_masuk()
    {
        $this->load->model('transaksi_model');
        $this->load->model('stok_model');

        $id_barang = $this->input->post('id_barang');

        $barang = $this->stok_model->satu_barang($id_barang);

        $data = [
            'tanggal' => date('Y-m-d'),
            'jumlah' => $this->input->post('jumlah'),
            'keterangan' => $this->input->post('keterangan'),
            'id_barang' => $id_barang,
        ];

        $hitungStok = $barang[0]['stok'] + $this->input->post('jumlah');
        $update = [
            'stok' => $hitungStok
        ];

        $updateStokBarang = $this->stok_model->update_barang($update, $id_barang);

        if ($updateStokBarang) {
            $proses = $this->transaksi_model->tambah_barang_masuk($data);

            if ($proses) {
                $this->session->set_flashdata('sukses', 'Berhasil tambah barang masuk.');
                redirect('/user/barang_masuk');
            } else {
                $this->session->set_flashdata('eror', 'Gagal ');
                redirect('/user/barang_masuk');
            }
        } else {
            $this->session->set_flashdata('eror', 'Gagal update stok barang.');
            redirect('/user/barang_masuk');
        }
    }

    public function update_barang_masuk()
    {
        $this->load->model('transaksi_model');
        $this->load->model('stok_model');

        $id_barang = $this->input->post('id_barang');
        $id = $this->input->post('id');

        $barang = $this->stok_model->satu_barang($id_barang);
        $barangMasuk = $this->transaksi_model->satu_barang_masuk($id);

        $data = [
            'tanggal' => date('Y-m-d'),
            'jumlah' => $this->input->post('jumlah'),
            'keterangan' => $this->input->post('keterangan'),
            'id_barang' => $id_barang,
        ];

        $stokSaatIni = $barang[0]['stok'];
        $normalisasiStok = $stokSaatIni - $barangMasuk[0]['jumlah'];

        $hitungStok = $normalisasiStok + $this->input->post('jumlah');
        $update = [
            'stok' => $hitungStok
        ];

        $updateStokBarang = $this->stok_model->update_barang($update, $id_barang);

        if ($updateStokBarang) {
            $proses = $this->transaksi_model->update_barang_masuk($data, $id);

            if ($proses) {
                $this->session->set_flashdata('sukses', 'Berhasil update barang masuk.');
                redirect('/user/barang_masuk');
            } else {
                $this->session->set_flashdata('eror', 'Gagal ');
                redirect('/user/barang_masuk');
            }
        } else {
            $this->session->set_flashdata('eror', 'Gagal update stok barang.');
            redirect('/user/barang_masuk');
        }
    }

    public function hapus_Barang_masuk($id)
    {
        $this->load->model('transaksi_model');
        $proses = $this->transaksi_model->hapus_barang_masuk($id);

        if ($proses) {
            $this->session->set_flashdata('sukses', 'Berhasil hapus barang masuk.');
            redirect('/user/barang_masuk');
        } else {
            $this->session->set_flashdata('eror', 'Gagal bjir');
            redirect('/user/barang_masuk');
        }
    }

    public function barang_keluar()
    {
        $this->load->model('transaksi_model');
        $this->load->model('stok_model');
        $data['title'] = 'barang keluar ';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        // MISALNYA lu masu ngambil db barang masuk di model tadi
        $data['Barang_keluar'] = $this->transaksi_model->barang_keluar(); // kok eror asu mana gw tau asw 
        $data['barang'] = $this->stok_model->ambil_semua_barang_masuk();

        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar', $data);
        $this->load->view('template/topbar', $data);
        $this->load->view('barang/barang_keluar');
        $this->load->view('template/footer');
    }

    public function tambah_barang_keluar()
    {
        $this->load->model('transaksi_model');
        $this->load->model('stok_model');

        $id_barang = $this->input->post('id_barang');

        $barang = $this->stok_model->satu_barang($id_barang);

        $data = [
            'tanggal' => date('Y-m-d'),
            'jumlah' => $this->input->post('jumlah'),
            'keterangan' => $this->input->post('keterangan'),
            'id_barang' => $id_barang,
        ];

        $hitungStok = $barang[0]['stok'] - $this->input->post('jumlah');
        $update = [
            'stok' => $hitungStok
        ];

        $updateStokBarang = $this->stok_model->update_barang($update, $id_barang);

        if ($updateStokBarang) {
            $proses = $this->transaksi_model->tambah_barang_keluar($data);

            if ($proses) {
                $this->session->set_flashdata('sukses', 'Berhasil tambah barang keluar.');
                redirect('/user/barang_keluar');
            } else {
                $this->session->set_flashdata('eror', 'Gagal');
                redirect('/user/barang_keluar');
            }
        } else {
            $this->session->set_flashdata('eror', 'Gagal update barang keluar.');
            redirect('/user/barang_keluar');
        }
    }

    public function hapus_Barang_keluar($id)
    {
        $this->load->model('transaksi_model');
        $proses = $this->transaksi_model->hapus_barang_keluar($id);

        if ($proses) {
            $this->session->set_flashdata('sukses', 'Berhasil hapus barang Keluar .');
            redirect('/user/barang_keluar');
        } else {
            $this->session->set_flashdata('eror', 'Gagal bjir');
            redirect('/user/barang_keluar');
        }
    }
    public function catatan()
    {
        $this->load->model('catatan_model');
        $data['title'] = 'catatan';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        // MISALNYA lu masu ngambil db barang masuk di model tadi
        $data['ambil_catatan'] = $this->catatan_model->ambil_semua_catatan(); // kok eror asu mana gw tau asw 

        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar', $data);
        $this->load->view('template/topbar', $data);
        $this->load->view('barang/catatan',$data);
        $this->load->view('template/footer');
    }

    public function hapus_catatan()
    {
        $this->load->model('catatan_model');
        $id = $this->input->post('id');

        $proses = $this->catatan_model->hapus_Catatan($id);

        if ($proses) {
            $this->session->set_flashdata('sukses', 'Berhasil hapus catatan.');
            redirect('/user/catatan');
        } else {
            $this->session->set_flashdata('eror', 'Gagal');
            redirect('/user/catatan');
        }
    }
    public function edit()
    {
        $data['title'] = 'Edit Profile';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('name', 'Full Name', 'required|trim');

        if ($this->form_validation->run() == false) {
            $this->load->view('template/header', $data);
            $this->load->view('template/sidebar', $data);
            $this->load->view('template/topbar', $data);
            $this->load->view('user/edit', $data);
            $this->load->view('template/footer');
        } else {
            $name = $this->input->post('name');
            $email = $this->input->post('email');

            // cek jika ada gambar yang akan diupload
            $upload_image = $_FILES['image']['name'];

            if ($upload_image) {
                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size']      = '2048';
                $config['upload_path'] = './assets/img/profile/';

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('image')) {
                    $old_image = $data['user']['image'];
                    if ($old_image != 'default.jpg') {
                        unlink(FCPATH . 'assets/img/profile/' . $old_image);
                    }
                    $new_image = $this->upload->data('file_name');
                    $this->db->set('image', $new_image);
                } else {
                    echo $this->upload->dispay_errors();
                }
            }

            $this->db->set('name', $name);
            $this->db->where('email', $email);
            $this->db->update('user');

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Your profile has been updated!</div>');
            redirect('user');
        }
    }
    public function tambah_catatan()
    {
        $this->load->model('catatan_model');
        $data = [
            'nama' => $this->input->post('nama'),
            'kategori' => $this->input->post('kategori'),
            'keterangan' => $this->input->post('keterangan'),
        ];

        $proses = $this->catatan_model->tambah_catatan($data);

        if ($proses) {
            $this->session->set_flashdata('sukses', 'Berhasil tambahin catatan.');
            redirect('/user/catatan');
        } else {
            $this->session->set_flashdata('eror', 'Gagal');
            redirect('/user/catatan');
        }
    }
    public function update_catatan()
    {
        $this->load->model('catatan_model');
        $data = [
            'nama' => $this->input->post('nama'),
            'kategori' => $this->input->post('kategori'),
            'keterangan' => $this->input->post('keterangan'),
           
        ];

        $id = $this->input->post('id');

        $proses = $this->catatan_model->update_catatan($data, $id);

        if ($proses) {
            $this->session->set_flashdata('sukses', 'Berhasil update catatan.');
            redirect('/user/catatan');
        } else {
            $this->session->set_flashdata('eror', 'Gagal ');
            redirect('/user/catatan');
        }
    }

}
