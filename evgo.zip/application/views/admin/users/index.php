<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Data Users</h1>

    <!-- Pesan -->
    <?php if ($this->session->flashdata('sukses')) { ?>
        <div class="alert alert-success" role="alert">
            <?= $this->session->flashdata('sukses') ?>
        </div>
    <?php } ?>

    <?php if ($this->session->flashdata('eror')) { ?>
        <div class="alert alert-success" role="alert">
            <?= $this->session->flashdata('eror') ?>
        </div>
    <?php } ?>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="<?= base_url('admin/tambah_user') ?>" class="btn btn-primary">Tambah Data</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <div id="dataTable_wrapper" class="dataTables_wrapper dt-bootstrap4">
                    <div class="row">
                        <div class="col-sm-12">
                            <table class="table table-bordered dataTable" id="dataTable" width="100%" cellspacing="0" role="grid" aria-describedby="dataTable_info" style="width: 100%;">
                                <thead>
                                    <tr>
                                        <th>
                                            No
                                        </th>
                                        <th>
                                            Poto
                                        </th>
                                        <th>Nama</th>
                                        <th>Email</th>
                                        <th>Role</th>
                                        <th>Opsi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no = 1;

                                    foreach ($users as $user) :

                                    ?>

                                        <tr>
                                            <td>
                                                <?= $no++; ?>
                                            </td>
                                            <td>
                                                <img src="<?= base_url('assets/img/profile/' . $user['image']); ?>" width="100" height="100" />
                                            </td>
                                            <td>
                                                <?= $user['name']; ?>
                                            </td>
                                            <td>
                                                <?= $user['email']; ?>
                                            </td>
                                            <td>
                                                <?= $user['role']; ?>
                                            </td>
                                            <td>
                                                <button type="button" data-toggle="modal" data-target="#update_modal<?= $user['id']; ?>" class=" btn btn-primary">Update</button>
                                                <button type="button" data-toggle="modal" data-target="#ganti_role_modal<?= $user['id']; ?>" class="btn btn-info">Ganti Role</button>
                                                <button type="button" data-toggle="modal" data-target="#delete_modal<?= $user['id']; ?>" class="btn btn-danger">Delete</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php

foreach ($users as $user) :

?>
    <!-- Modal Ganti Role -->
    <div class="modal fade" id="ganti_role_modal<?= $user['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form action="<?= base_url('admin/ganti_role'); ?>" method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLabel">Ganti Role</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="id" value="<?= $user['id'] ?>">

                        <div class="form-group">
                            <label>Role</label>
                            <select name="role_id" class="form-control">
                                <?php
                                foreach ($roles as $role) :
                                ?>
                                    <option value="<?= $role['id'] ?>" <?php if ($user['role_id'] == $role['id']) {
                                                                            echo 'selected';
                                                                        } ?>><?= $role['role'] ?></option>
                                <?php
                                endforeach;
                                ?>
                            </select>
                        </div>


                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <button class="btn btn-primary" type="submit">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php endforeach; ?>


<?php foreach ($users as $bm) : ?>
    <div class="modal fade" id="delete_modal<?= $bm['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    Hapus data <?= $bm['name']; ?>?
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="<?= base_url('/user/hapus_users/') . $bm['id']; ?>">Hapus</a>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>