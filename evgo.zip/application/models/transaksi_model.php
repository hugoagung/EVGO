<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Transaksi_Model extends CI_Model
{
    public function barang_masuk()
    {
        $this->db->select(['barang_masuk.tanggal', 'barang_masuk.jumlah', 'barang_masuk.keterangan', 'barang_masuk.id_barang', 'barang_masuk.id', 'stok_barang.nama_barang', 'stok_barang.kategori']);
        $this->db->join('stok_barang', 'stok_barang.id = barang_masuk.id_barang');
        return $this->db->get('barang_masuk')->result_array();
    }

    public function satu_barang_masuk($id)
    {
        return $this->db->get_where('barang_masuk', ['id' => $id])->result_array();
    }

    public function update_barang_masuk($data, $id)
    {
        $this->db->set($data);
        $this->db->where('id', $id);
        return $this->db->update('barang_masuk');
    }

    public function tambah_barang_masuk($data)
    {
        return $this->db->insert('barang_masuk', $data);
    }

    public function hapus_barang_masuk($id)
    {
        return $this->db->delete('barang_masuk', ['id' => $id]);
    }

    // Barang keluar
    public function barang_keluar()
    {
        $this->db->select(['barang_keluar.tanggal', 'barang_keluar.jumlah', 'barang_keluar.keterangan', 'barang_keluar.id_barang', 'barang_keluar.id', 'stok_barang.nama_barang', 'stok_barang.kategori']);
        $this->db->join('stok_barang', 'stok_barang.id = barang_keluar.id_barang');
        return $this->db->get('barang_keluar')->result_array();
    }

    public function tambah_barang_keluar($data)
    {
        return $this->db->insert('barang_keluar', $data);
    }

    public function hapus_barang_keluar($id)
    {
        return $this->db->delete('barang_keluar', ['id' => $id]);
    }
}
