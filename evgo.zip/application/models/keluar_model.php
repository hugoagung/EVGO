<?php
defined('BASEPATH') or exit('No direct script access allowed');

class keluar_Model extends CI_Model
{
    public function barang_keluar()
    {
        $this->db->select(['barang_keluar.tanggal', 'barang_keluar.jumlah', 'barang_keluar.keterangan', 'barang_keluar.id_barang', 'barang_keluar.id', 'stok_barang.nama_barang', 'stok_barang.kategori']);
        $this->db->join('stok_barang', 'stok_barang.id = barang_keluar.id_barang');
        return $this->db->get('barang_keluar')->result_array();
    }
    public function hapus_barang_keluar($id)
    {
        return $this->db->delete('barang_keluar', ['id' => $id]);
    }
}
