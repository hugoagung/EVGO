<?php

class Users_model extends CI_Model
{
    public function ambil_semua_data_user()
    {
        $this->db->select(['user.id', 'user.name', 'user.email', 'user.role_id', 'role.role', 'user.image']);
        $this->db->from('user');
        $this->db->join('role', 'role.id=user.role_id', 'left');
        return $this->db->get()->result_array();
    }

    public function tambah_data_user($data)
    {
        return $this->db->insert('user', $data);
    }
    public function Update_data_user($data)
    {
        return $this->db->update('user', $data);
    }

    public function ganti_role($data, $id)
    {
        $this->db->where('id', $id);
        return $this->db->update('user', $data);
    }
    public function hapus_data_user($id)
    {
        return $this->db->delete('user', ['id' => $id]);
    }
}
